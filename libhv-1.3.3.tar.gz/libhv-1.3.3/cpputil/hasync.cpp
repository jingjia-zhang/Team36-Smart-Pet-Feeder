#include "hasync.h"

namespace hv {

SINGLETON_IMPL(GlobalThreadPool)

}
